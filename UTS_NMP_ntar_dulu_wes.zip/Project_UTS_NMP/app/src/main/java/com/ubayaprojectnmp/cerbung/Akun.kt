package com.ubayaprojectnmp.cerbung

class Akun(val username:String, val password:String) {
}