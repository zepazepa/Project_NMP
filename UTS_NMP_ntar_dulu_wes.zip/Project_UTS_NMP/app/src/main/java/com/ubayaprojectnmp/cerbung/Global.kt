package com.ubayaprojectnmp.cerbung

object Global {
    val cerbung = arrayListOf(
        Cerbung(0,"Petualangan Herina","Zzzefa",Genre(1,"Action"),"28/09/2023", 234, "https://live.staticflickr.com/737/32640476365_906f64ce29_b.jpg","Setelah kembali dari petualangan musim panas dengan Sherina, Herina merasa semangat petualangan masih terus membara di dalam dirinya. Dia memutuskan untuk mewujudkan mimpinya menjadi penjelajah alam sejati. Dengan peta kuno yang ditemukan oleh ayahnya, Herina berangkat ke pulau terpencil yang penuh dengan misteri dan rintangan alam yang menantang.",1,"Matahari terbit dengan gemerlap keemasan di langit pagi, menerangi pulau terpencil yang dikelilingi oleh ombak biru. Herina berdiri di tepi pantai, mendengarkan suara ombak yang menghantam pantai pasir putih. Angin sejuk membelai rambutnya, dan di matanya berkilau semangat yang tak terpadamkan. Di tangan kirinya, dia memegang peta kuno yang telah mewarisi dari ayahnya, mengandung petunjuk menuju petualangan besar yang dia idamkan. Saat ini, Herina memutuskan untuk melangkah keluar dari bayang-bayang sahabatnya, Sherina, dan memulai perjalanannya sendiri menuju petualangan yang akan mengubah hidupnya selamanya."),
        Cerbung(1,"2 Tahun","lil Jennie",Genre(7,"Horror"),"17/09/2023", 2321,"https://gallery.poskota.co.id/storage/Foto/santai-2.jpg","Setelah waktu yang lama, Mandy pulang ke kampung halamannya untuk kembali bertemu dengan keluarganya. Namun, ia tidak akan menyangka apa yang akan menyambutnya di sana.",1,"\"Aku akan pulang!\" pikir Mandy sebelum masa liburan lebaran tiba. Ia sudah menyiapkan semua barang yang akan di bawanya, mulai dari pakaian, makanan, oleh-oleh, hingga titipan adik kecilnya."),
        Cerbung(2,"Asal Bisa Kembali","Valencinan",Genre(9, "Romance"),"15/08/2023",3,"https://gallery.poskota.co.id/storage/Foto/santai-2.jpg","Menjelang hilangnya pacarnya, Dandy, Maria berusaha dengan sepenuh hatinya untuk bisa mencari Dandy. Walaupun terjerat dengan berbagai kasus, Maria harus tetap berusaha untuk membebaskan Dandy. Akankah Maria berhasil?",1,"Polisi datang setelah melihat video itu tersebar di sosial media. Aku tak bisa membayangkan bagaimana ia masih bisa tersenyum. Apakah mungkin ia sudah tak sehat? tidak mungkin! sehari sebelumnya ia masih memelukku dengan erat di perempatan jalan itu")
    )
    val username = "admin"
    val password = "admin"
    val akun = arrayListOf(
        Akun("Valencio","160421005"),
        Akun("Zefanya","160421033"),
        Akun("Jennie","160421039")
    )
    val genre = arrayOf(
        Genre(1, "Action"),
        Genre(2, "Anime"),
        Genre(3, "Comedy"),
        Genre(4, "Crime"),
        Genre(5, "Drama"),
        Genre(6, "History"),
        Genre(7, "Horror"),
        Genre(8, "Kids"),
        Genre(9, "Romance"),
        Genre(10, "Sci-Fi & Fantasy"),
        Genre(11, "Thriller")
    )
}