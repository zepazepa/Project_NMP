package com.ubayaprojectnmp.cerbung

class Cerbung (val id:Int, val title:String, val creator:String, val genre:Genre, val tglDibuat:String, val like:Int, val imgurl:String,
val sinopsis:String,val num_paragraf:Int, val paragraf:String){

}