package com.ubayaprojectnmp.cerbung

class Genre(val id:Int, val nama:String) {
    override fun toString(): String {
        return nama
    }
}